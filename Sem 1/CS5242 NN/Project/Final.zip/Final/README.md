# CS5242-Final-Project

To install dependencies:
```shell
$ pip3 install -r requirements.txt
```
