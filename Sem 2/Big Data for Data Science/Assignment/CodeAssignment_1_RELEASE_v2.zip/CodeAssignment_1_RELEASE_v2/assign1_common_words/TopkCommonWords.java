/*
ENTER YOUR NAME HERE
NAME: JOHN DOE
MATRICULATION NUMBER: A0123456X
*/

public class TopkCommonWords {
    public static void main(String[] args){

    } 
}
