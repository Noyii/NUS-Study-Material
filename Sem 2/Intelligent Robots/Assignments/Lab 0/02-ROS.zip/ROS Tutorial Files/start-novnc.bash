#!/bin/bash
sudo USER=ir /startup.sh
