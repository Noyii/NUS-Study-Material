# Miscellaneous Items for Lab 1

- `docker_env`: Files to build the docker environment. 
- `turtlesim_goto.py`: The script used during lab1pre.
