// Auto-generated. Do not edit!

// (in-package planner.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let DiscreteAction = require('../msg/DiscreteAction.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class DiscreteActionSequenceExecRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plan = null;
    }
    else {
      if (initObj.hasOwnProperty('plan')) {
        this.plan = initObj.plan
      }
      else {
        this.plan = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteActionSequenceExecRequest
    // Serialize message field [plan]
    // Serialize the length for message field [plan]
    bufferOffset = _serializer.uint32(obj.plan.length, buffer, bufferOffset);
    obj.plan.forEach((val) => {
      bufferOffset = DiscreteAction.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteActionSequenceExecRequest
    let len;
    let data = new DiscreteActionSequenceExecRequest(null);
    // Deserialize message field [plan]
    // Deserialize array length for message field [plan]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.plan = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.plan[i] = DiscreteAction.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 16 * object.plan.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'planner/DiscreteActionSequenceExecRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e521fc6729cde49c198405b9ac85c488';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    DiscreteAction[] plan
    
    ================================================================================
    MSG: planner/DiscreteAction
    int64[2] action
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteActionSequenceExecRequest(null);
    if (msg.plan !== undefined) {
      resolved.plan = new Array(msg.plan.length);
      for (let i = 0; i < resolved.plan.length; ++i) {
        resolved.plan[i] = DiscreteAction.Resolve(msg.plan[i]);
      }
    }
    else {
      resolved.plan = []
    }

    return resolved;
    }
};

class DiscreteActionSequenceExecResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.done = null;
    }
    else {
      if (initObj.hasOwnProperty('done')) {
        this.done = initObj.done
      }
      else {
        this.done = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteActionSequenceExecResponse
    // Serialize message field [done]
    bufferOffset = _serializer.bool(obj.done, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteActionSequenceExecResponse
    let len;
    let data = new DiscreteActionSequenceExecResponse(null);
    // Deserialize message field [done]
    data.done = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'planner/DiscreteActionSequenceExecResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '89bb254424e4cffedbf494e7b0ddbfea';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool done
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteActionSequenceExecResponse(null);
    if (msg.done !== undefined) {
      resolved.done = msg.done;
    }
    else {
      resolved.done = false
    }

    return resolved;
    }
};

module.exports = {
  Request: DiscreteActionSequenceExecRequest,
  Response: DiscreteActionSequenceExecResponse,
  md5sum() { return '91ff49182988a1ea91fbf16d8eb8707c'; },
  datatype() { return 'planner/DiscreteActionSequenceExec'; }
};
