// Auto-generated. Do not edit!

// (in-package planner.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ContinuousAction = require('../msg/ContinuousAction.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class ContinuousActionSequenceExecRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plan = null;
    }
    else {
      if (initObj.hasOwnProperty('plan')) {
        this.plan = initObj.plan
      }
      else {
        this.plan = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ContinuousActionSequenceExecRequest
    // Serialize message field [plan]
    // Serialize the length for message field [plan]
    bufferOffset = _serializer.uint32(obj.plan.length, buffer, bufferOffset);
    obj.plan.forEach((val) => {
      bufferOffset = ContinuousAction.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ContinuousActionSequenceExecRequest
    let len;
    let data = new ContinuousActionSequenceExecRequest(null);
    // Deserialize message field [plan]
    // Deserialize array length for message field [plan]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.plan = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.plan[i] = ContinuousAction.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 16 * object.plan.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'planner/ContinuousActionSequenceExecRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b2ba0ec57a4e884d5618d6788f4e5cce';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ContinuousAction[] plan
    
    ================================================================================
    MSG: planner/ContinuousAction
    float64 v
    float64 w
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ContinuousActionSequenceExecRequest(null);
    if (msg.plan !== undefined) {
      resolved.plan = new Array(msg.plan.length);
      for (let i = 0; i < resolved.plan.length; ++i) {
        resolved.plan[i] = ContinuousAction.Resolve(msg.plan[i]);
      }
    }
    else {
      resolved.plan = []
    }

    return resolved;
    }
};

class ContinuousActionSequenceExecResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.done = null;
    }
    else {
      if (initObj.hasOwnProperty('done')) {
        this.done = initObj.done
      }
      else {
        this.done = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ContinuousActionSequenceExecResponse
    // Serialize message field [done]
    bufferOffset = _serializer.bool(obj.done, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ContinuousActionSequenceExecResponse
    let len;
    let data = new ContinuousActionSequenceExecResponse(null);
    // Deserialize message field [done]
    data.done = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'planner/ContinuousActionSequenceExecResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '89bb254424e4cffedbf494e7b0ddbfea';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool done
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ContinuousActionSequenceExecResponse(null);
    if (msg.done !== undefined) {
      resolved.done = msg.done;
    }
    else {
      resolved.done = false
    }

    return resolved;
    }
};

module.exports = {
  Request: ContinuousActionSequenceExecRequest,
  Response: ContinuousActionSequenceExecResponse,
  md5sum() { return '3a13953924540c1e79bc61428b7539e6'; },
  datatype() { return 'planner/ContinuousActionSequenceExec'; }
};
