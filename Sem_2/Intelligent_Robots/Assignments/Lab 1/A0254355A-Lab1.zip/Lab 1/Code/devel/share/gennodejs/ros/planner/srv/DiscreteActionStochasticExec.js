// Auto-generated. Do not edit!

// (in-package planner.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let DiscreteAction = require('../msg/DiscreteAction.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class DiscreteActionStochasticExecRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.action = null;
    }
    else {
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = new DiscreteAction();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteActionStochasticExecRequest
    // Serialize message field [action]
    bufferOffset = DiscreteAction.serialize(obj.action, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteActionStochasticExecRequest
    let len;
    let data = new DiscreteActionStochasticExecRequest(null);
    // Deserialize message field [action]
    data.action = DiscreteAction.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'planner/DiscreteActionStochasticExecRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '213ebcfcf0a3985a5684a88bbbb34803';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    DiscreteAction action
    
    ================================================================================
    MSG: planner/DiscreteAction
    int64[2] action
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteActionStochasticExecRequest(null);
    if (msg.action !== undefined) {
      resolved.action = DiscreteAction.Resolve(msg.action)
    }
    else {
      resolved.action = new DiscreteAction()
    }

    return resolved;
    }
};

class DiscreteActionStochasticExecResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.done = null;
    }
    else {
      if (initObj.hasOwnProperty('done')) {
        this.done = initObj.done
      }
      else {
        this.done = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteActionStochasticExecResponse
    // Serialize message field [done]
    bufferOffset = _serializer.bool(obj.done, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteActionStochasticExecResponse
    let len;
    let data = new DiscreteActionStochasticExecResponse(null);
    // Deserialize message field [done]
    data.done = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'planner/DiscreteActionStochasticExecResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '89bb254424e4cffedbf494e7b0ddbfea';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool done
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteActionStochasticExecResponse(null);
    if (msg.done !== undefined) {
      resolved.done = msg.done;
    }
    else {
      resolved.done = false
    }

    return resolved;
    }
};

module.exports = {
  Request: DiscreteActionStochasticExecRequest,
  Response: DiscreteActionStochasticExecResponse,
  md5sum() { return '9006ebc0e79e66bb7f82e2e994f6614a'; },
  datatype() { return 'planner/DiscreteActionStochasticExec'; }
};
